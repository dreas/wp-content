<p><br>Thank you for using Content Views.</p>
<p>You are using version <code><?php echo esc_html( PT_CV_Functions::plugin_info( PT_CV_FILE, 'Version' ) ); ?></code></p>